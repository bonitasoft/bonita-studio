package org.bonitasoft.connector.processcloner;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.bonitasoft.engine.api.ActorSorting;
import org.bonitasoft.engine.api.ProcessAPI;
import org.bonitasoft.engine.bpm.bar.BusinessArchiveBuilder;
import org.bonitasoft.engine.bpm.model.ActorInstance;
import org.bonitasoft.engine.bpm.model.DesignProcessDefinition;
import org.bonitasoft.engine.bpm.model.ProcessDefinition;
import org.bonitasoft.engine.bpm.model.ProcessDefinitionBuilder;
import org.bonitasoft.engine.bpm.model.ProcessInstance;
import org.bonitasoft.engine.exception.ConnectorException;
import org.bonitasoft.engine.identity.User;

public class ProcessClonerImpl extends AbstractProcessClonerImpl {

	@Override
	protected void executeBusinessLogic() throws org.bonitasoft.engine.exception.ConnectorException{
		//TODO List of process name and version for many def
		//Import organization from existing file
		//Import userXP profile
		//
		final int nbInstances = getNbInstance();
		final String userName = getUserName();
		final List<Long> result = new ArrayList<Long>();

		final ProcessAPI processAPI = getAPIAccessor().getProcessAPI();
		final String delivery = "Delivery men";

		try{
			final ProcessDefinitionBuilder processBuilder = new ProcessDefinitionBuilder().createNewInstance("DeliveryProcess", "1.0");
			processBuilder.addActor(delivery).addDescription("Delivery all day and night long").addUserTask("deliver", delivery) ;
			DesignProcessDefinition processDefinition =  processBuilder.done();
			ProcessDefinition definition =  processAPI.deploy(new BusinessArchiveBuilder().createNewBusinessArchive().setProcessDefinition(processDefinition).done());
			List<ActorInstance> actors = processAPI.getActors(definition.getId(), 0, 50, ActorSorting.NAME_ASC);
			ActorInstance actorInstance = null;
			for (final ActorInstance actor : actors) {
				if (actor.getName().equals(delivery)) {
					actorInstance = actor;
				}
			}
			User user = getAPIAccessor().getIdentityAPI().getUserByUserName(userName);
			processAPI.addUserToActor(actorInstance.getId(),user.getId());
			processAPI.enableProcess(definition.getId());
			for(int i = 0 ; i<nbInstances ;i++){
				ProcessInstance instance = processAPI.startProcess(definition.getId());
				result.add(instance.getId());
			}
		}catch (Exception e) {
			setProcessInstanceIds(Collections.unmodifiableList(result));
			throw new ConnectorException(e);
		}

		setProcessInstanceIds(Collections.unmodifiableList(result));
	}

}
