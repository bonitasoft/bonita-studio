package org.bonitasoft.connector.processcloner;

import org.bonitasoft.engine.connector.AbstractConnector;

public abstract class AbstractProcessClonerImpl extends AbstractConnector {

	protected final String NBINSTANCE_INPUT_PARAMETER = "nbInstance";
	protected final String USERNAME_INPUT_PARAMETER = "userName";
	protected final String PROCESSINSTANCEIDS_OUTPUT_PARAMETER = "processInstanceIds";

	protected final java.lang.Integer getNbInstance() {
		return (java.lang.Integer) getInputParameter(NBINSTANCE_INPUT_PARAMETER);
	}

	protected final java.lang.String getUserName() {
		return (java.lang.String) getInputParameter(USERNAME_INPUT_PARAMETER);
	}

	protected final void setProcessInstanceIds(java.util.List processInstanceIds) {
		setOutputParameter(PROCESSINSTANCEIDS_OUTPUT_PARAMETER,
				processInstanceIds);
	}

	@Override
	public void validateInputParameters()
			throws org.bonitasoft.engine.exception.ConnectorValidationException {
		try {
			getNbInstance();
		} catch (ClassCastException cce) {
			throw new org.bonitasoft.engine.exception.ConnectorValidationException(
					"nbInstance type is invalid");
		}
		try {
			getUserName();
		} catch (ClassCastException cce) {
			throw new org.bonitasoft.engine.exception.ConnectorValidationException(
					"userName type is invalid");
		}

	}

}
