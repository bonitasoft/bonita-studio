angular.module('org.bonitasoft.pagebuilder.widgets')
  .directive('pbButton', function() {
    return {
      controllerAs: 'ctrl',
      controller: function PbButtonCtrl($scope, $http, $timeout, $location) {

  'use strict';
  if ($scope.properties.action === "Start process") {
    var process = getProcess();
    if (process) {
      var promise = $http.get('/bonita/API/bpm/process?c=1&p=0&f=name=' + process.name + '&f=version=' + process.version);
    }
  }

  this.action = function action() {
    if ($scope.properties.toCopy) {
      copy();
    }

    if ($scope.properties.action === 'Remove from collection') {
      removeFromCollection();
    } else if ($scope.properties.action === 'Add to collection') {
      addToCollection();
    } else if ($scope.properties.action === "Start process") {
      promise.then(function (result) {
        doRequestDelayed('POST', '/bonita/API/bpm/process/' + result.data[0].id + '/instantiation');
      });
    } else if ($scope.properties.action === 'Submit task') {
      doRequestDelayed('POST', '/bonita/API/bpm/userTask/' + getTaskId() + '/execution');
    } else if ($scope.properties.action !== 'None' && $scope.properties.destUrl) {
      doRequestDelayed($scope.properties.action, $scope.properties.destUrl);
    }
  };

  function removeFromCollection() {
    if ($scope.properties.collectionToModify) {
      if (!Array.isArray($scope.properties.collectionToModify)) {
        throw 'Collection property for widget button should be an array, but was ' + $scope.properties.collectionToModify;
      }

      if ($scope.properties.collectionPosition === 'First') {
        $scope.properties.collectionToModify.shift();
      } else {
        $scope.properties.collectionToModify.pop();
      }
    }
  }

  function addToCollection() {
    if (!$scope.properties.collectionToModify) {
      $scope.properties.collectionToModify = [];
    }
    if (!Array.isArray($scope.properties.collectionToModify)) {
      throw 'Collection property for widget button should be an array, but was ' + $scope.properties.collectionToModify;
    }

    if ($scope.properties.collectionPosition === 'First') {
      $scope.properties.collectionToModify.unshift($scope.properties.valueToAdd);
    } else {
      $scope.properties.collectionToModify.push($scope.properties.valueToAdd);
    }
  }

  // we delayed the doRequest to ensure dataToSend is updated
  // this usefull when copy() update the dataToSend object.
  function doRequestDelayed(method, url) {
    $timeout(function () {
      doRequest(method, url);
    }, false);
  }

  /**
   * Execute a get/post request to an URL
   * It also bind custom data from success|error to a data
   * @return {void}
   */
  function doRequest(method, url) {
    var req = {
      method: method,
      url: url,
      data: angular.copy($scope.properties.dataToSend)
    };

    $http(req)
      .success(function (data) {
        $scope.properties.dataFromSuccess = data;
      })
      .error(function (data) {
        $scope.properties.dataFromError = data;
      });
  }

  function getTaskId() {
    // return last path info i.e. /some/url/{taskId}?locale=en..
    return getTaskIdUrlSegment($location.absUrl());
  }

  function getTaskIdUrlSegment(url) {
    return url.match('form\/taskInstance\/(.*)\/[?$]')[1];
  }

  function getProcess() {
    var lastTwoSegments = getProcessUrlSegment($location.absUrl());
    if (lastTwoSegments) {
      return { name: lastTwoSegments[1], version: lastTwoSegments[2] };
    }
  }

  function getProcessUrlSegment(url) {
    return url.match('form\/process\/(.*)\/(.*)\/[?$]');
  }

  /**
   * Copy a data
   * @return {void}
   */
  function copy() {
    $scope.properties.model = $scope.properties.toCopy;
  }
}
,
      template: '<div class="text-{{ properties.alignment }}">\n    <button\n        ng-class="\'btn btn-\' + properties.buttonStyle"\n        ng-click="ctrl.action()"\n        ng-disabled="properties.isDisabled">{{ properties.label }}</button>\n</div>\n'
    };
  });
