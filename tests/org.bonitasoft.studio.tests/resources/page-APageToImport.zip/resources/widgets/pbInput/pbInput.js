angular.module('org.bonitasoft.pagebuilder.widgets')
  .directive('pbInput', function() {
    return {
      template: '<div class="row">\n    <label\n        ng-if="!properties.labelHidden"\n        ng-class="{ \'widget-label-horizontal\': !properties.labelHidden && properties.labelPosition === \'left\'}"\n        class="col-xs-{{ !properties.labelHidden && properties.labelPosition === \'left\' ? properties.labelWidth : 12 }}">\n        {{ properties.label }}\n    </label>\n\n    <div class="col-xs-{{ 12 - (!properties.labelHidden && properties.labelPosition === \'left\' ? properties.labelWidth : 0) }}">\n        <input\n            type="{{properties.type}}"\n            class="form-control"\n            placeholder="{{ properties.placeholder }}"\n            ng-model="properties.value"\n            ng-readonly="properties.readOnly">\n    </div>\n\n</div>\n'
    };
  });
