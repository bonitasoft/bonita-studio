package org.bonitasoft.tests;

import java.util.List;
import org.bonitasoft.engine.exception.UserFilterException;

public class MyActorFilterTest extends AbstractMyActorFilterTest {

	@Override
	public List<Long> filter(List<String> users) throws UserFilterException {
		//TODO execute the user filter here
		//The method must return a list of user ids
		//you can use getApiAccessor() and getExecutionContext()
		return null;
	
	}

	@Override
	public boolean shouldAutoAssignTaskIfSingleResult() {
		// If this method returns true, the step will be assigned to 
		//the user if there is only one result returned by the filter method
		return super.shouldAutoAssignTaskIfSingleResult();
	
	}

}
