package org.bonitasoft.tests;

import org.bonitasoft.engine.filter.AbstractUserFilter;

public abstract class AbstractMyActorFilterTest extends AbstractUserFilter {

	@Override
	public void validateInputParameters()
			throws org.bonitasoft.engine.exception.ConnectorValidationException {

	}

}
