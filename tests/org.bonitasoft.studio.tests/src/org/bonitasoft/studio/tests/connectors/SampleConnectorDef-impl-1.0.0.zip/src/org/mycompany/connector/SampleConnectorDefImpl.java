package org.mycompany.connector;

import org.bonitasoft.engine.exception.ConnectorException;

public class SampleConnectorDefImpl extends AbstractSampleConnectorDefImpl {

	@Override
	protected void executeBusinessLogic() throws ConnectorException{
		//TODO execute your business logic here
		//Do not forget to use generated setters in parent class to set your connector output
	
	}

}
