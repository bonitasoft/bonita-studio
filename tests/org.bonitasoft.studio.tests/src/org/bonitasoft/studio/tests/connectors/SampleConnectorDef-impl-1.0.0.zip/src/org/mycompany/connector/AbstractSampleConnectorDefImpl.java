package org.mycompany.connector;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractSampleConnectorDefImpl extends AbstractConnector {

	@Override
	public void validateInputParameters() throws ConnectorValidationException {

	}

}
