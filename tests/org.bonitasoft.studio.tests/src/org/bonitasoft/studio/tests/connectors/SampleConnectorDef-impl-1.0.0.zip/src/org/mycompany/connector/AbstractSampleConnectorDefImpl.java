package org.mycompany.connector;

import org.bonitasoft.engine.connector.AbstractConnector;

public abstract class AbstractSampleConnectorDefImpl extends AbstractConnector {

	@Override
	public void validateInputParameters()
			throws org.bonitasoft.engine.exception.ConnectorValidationException {

	}

}
