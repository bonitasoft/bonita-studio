angular.module('org.bonitasoft.pagebuilder.widgets')
  .directive('pbButton', function() {
    return {
      controllerAs: 'ctrl',
      controller: function PbButtonCtrl ($scope, $http, $timeout) {

  'use strict';

  this.action = function action () {
    if ($scope.parameters.toCopy) {
      copy();
    }

    if ($scope.parameters.action === 'Remove from collection') {
      removeFromCollection();
    } else if ($scope.parameters.action === 'Add to collection') {
      addToCollection();
    } else if ($scope.parameters.action === 'Submit task') {
      doRequestDelayed('POST', '/bonita/API/bpm/tasks/' + getTaskId() + '/execute');
    } else if ($scope.parameters.action !== 'None' && $scope.parameters.destUrl) {
      doRequestDelayed($scope.parameters.action, $scope.parameters.destUrl);
    }
  };

  function removeFromCollection () {
    if ($scope.parameters.collectionToModify) {
      if (!Array.isArray($scope.parameters.collectionToModify)) {
        throw 'Collection parameter for widget button should be an array, but was ' + $scope.parameters.collectionToModify;
      }

      if ($scope.parameters.collectionPosition === 'First') {
        $scope.parameters.collectionToModify.shift();
      } else {
        $scope.parameters.collectionToModify.pop();
      }
    }
  }

  function addToCollection () {
    if (!$scope.parameters.collectionToModify) {
      $scope.parameters.collectionToModify = [];
    }
    if (!Array.isArray($scope.parameters.collectionToModify)) {
      throw 'Collection parameter for widget button should be an array, but was ' + $scope.parameters.collectionToModify;
    }

    if ($scope.parameters.collectionPosition === 'First') {
      $scope.parameters.collectionToModify.unshift($scope.parameters.valueToAdd);
    } else {
      $scope.parameters.collectionToModify.push($scope.parameters.valueToAdd);
    }
  }

  // we delayed the doRequest to ensure dataToSend is updated
  // this usefull when copy() update the dataToSend object.
  function doRequestDelayed (method, url) {
    $timeout(function() {
      doRequest(method, url);
    }, false);
  }

  /**
   * Execute a get/post request to an URL
   * It also bind custom data from success|error to a data
   * @return {void}
   */
  function doRequest (method, url) {
    var req = {
      method: method,
      url: url,
      data: angular.copy($scope.parameters.dataToSend)
    };

    $http(req)
      .success(function(data) {
        $scope.parameters.dataFromSuccess = data;
      })
      .error(function(data) {
        $scope.parameters.dataFromError = data;
      });
  }

  function getTaskId () {
    // return last path info i.e. /some/url/{taskId}
    return window.location.href.match(/([^\/]*)\/*$/)[1];
  }

  /**
   * Copy a data
   * @return {void}
   */
  function copy () {
    $scope.parameters.model = $scope.parameters.toCopy;
  }
}
,
      template: '<div class="text-{{ parameters.alignment }}">\n    <button\n        ng-class="\'btn btn-\' + parameters.buttonStyle"\n        ng-click="ctrl.action()"\n        ng-disabled="parameters.isDisabled">{{ parameters.label }}</button>\n</div>\n'
    };
  });
